#ifndef __Include_H_
#define __Include_H_


#include <stdio.h>
#include <stdarg.h>
#include "string.h"
//#include <IRremote.h> //v3.9.0
//#include <IRremoteInt.h>  //v3.9.0
//#include <SoftwareSerial.h>
//#include <Stepper.h>
#include "IRLed.h"
#include "Bluetooth.h"
#include "Motor.h"
#include "RGB_Led.h"
#include "zDefine.h"




#endif
