#ifndef __RGB_LED_H_
#define __RGB_LED_H_

void _printf(const char *s, ...);
void setColor(int rgain, int ggain, int bgain);
void RGB_LED_OFF();

#endif